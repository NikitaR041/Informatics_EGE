# Автор: А. Рогов

a = 'КИЛОБИТ'
i = 0
b = ''
while i < len(a):
    c = a[len(a) - i - 1]
    b += c
    i += 1
print(b)
