# Автор: А. Наймушин

def is_prime(x):
    for i in range(2, x):
        if x % i == 0:
            return False
    return True


for n in range(10, 200):
    s = '1' + '0' * n
    while '10' in s:
        if '10' in s:
            s = s.replace('10', '001', 1)
        elif '1' in s:
            s = s.replace('1', '0', 1)
    if (len(s)) > 100:
        print (n)
        break
'''
50
'''

