x = 1
for n in range(3303, 3300, -1):
  x *= n

print( x )