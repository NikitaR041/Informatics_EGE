d ={}
for x in range(1,10000):
  a = 2*x - 91
  b = 3*x - 159
  if a <= 0 or b <= 0: continue
  while a != b:
    if a > b:
      a -= b
    else:
      b -= a
  if not a in d:
    d[a] = x
    print( x, a )