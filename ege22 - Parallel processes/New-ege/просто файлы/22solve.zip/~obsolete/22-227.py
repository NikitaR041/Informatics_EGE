d = {}
total = 0
for s0 in range(1,10000):
  s = s0 #int(input())
  P = 15
  Q = 3
  K1 = 0
  K2 = 0
  while s <= 220:
    s = s + P
    K1 = K1 + 1
  while s >= Q:
    s = s - Q
    K2 = K2 + 1
  K1 += s
  K2 += s
  #print( s0, K1, K2 )
  d[(K1,K2)] = d.get((K1,K2), 0) + 1
  if K1 == 12 and K2 == 75:
    print(s0)
    total += s0

print( '*', total )

print( sorted(
       list( (k, d[k]) for k in d if d[k] > 1) ) )
