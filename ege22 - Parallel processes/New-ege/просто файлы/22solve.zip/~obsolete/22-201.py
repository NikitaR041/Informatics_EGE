# x = int(input())

x = int( '521111111', 8)
print(x)
a = 1
b = 0
while x > 0:
  d = x % 8
  a *= d
  b += d
  x //= 8
print(a, b)