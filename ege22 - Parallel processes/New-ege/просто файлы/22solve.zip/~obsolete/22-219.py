#x = int(input())
xx = 1
while xx < 100000:
    x = xx
    a = 18; b = 432
    while x > 0:
      a += 1
      if x % 2 == 1:
        b -= x % 100
      x //= 10
    if a == 22 and b == 246:
       print( xx)
    xx += 1