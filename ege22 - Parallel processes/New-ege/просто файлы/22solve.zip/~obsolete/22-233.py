N = 15120
Dmax = 5

s = 0
digit = 9
x = ''
while digit > 1:
  while N % digit == 0:
    if digit > Dmax:
      s += digit
    x += str(digit)
    N //= digit
  digit -= 1

x = int(x)
print( f"x = {x}, r = {N}" )
print( f"maxB = {s}" )

a = 1; b = 0
while x > 0:
  d = x % 10
  a *= d
  if d > Dmax:
    b += d
  x //= 10

print(a,b)
