
# x = int(input())
xx = 1
while True:
  x = xx
  L = 0; M = 0
  while x > 0:
    L = L + 1
    if x % 2 == 0:
      M = M + (x % 10) // 2
    x = x // 10
  # print("%d\n%d" % (L, M))
  if L == 3 and M == 7:
    print( xx )
    break
  xx += 1