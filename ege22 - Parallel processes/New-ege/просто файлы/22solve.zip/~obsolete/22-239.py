N = 5145
Dmax = 1

d = 2
x, s = '', 0
while N > 1:
  while N % d == 0:
    if d > Dmax: s += d
    x += str(d)
    N //= d
  d += 1

x = int(x)
print( f"x = {x}, r = 1" )
print( f"maxB = {s}" )

a = 1; b = 0
while x > 0:
  d = x % 10
  a *= d
  if d > Dmax:
    b += d
  x //= 10

print(a,b)