for xx in range(999, 0, -1):
    x = xx # int(input())
    K = 9*x - 57
    D = 9*x + 13
    while K*D > 0:
      if K > D:
        K = K % D
      else:
        D = D % K
    if K+D == 70: #print(K + D)
      print( xx )
      break
