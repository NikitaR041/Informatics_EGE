# x = int(input())

def dupSystem( s, b1, b2 ):
  if len(s) == 1:
    return int(s)
  else:
    return dupSystem( s[:-1], b2, b1 )*b1 + int(s[-1])

s = '5731111111'
x = dupSystem( s, 9, 6 )

print(x)
a = 2
b = 14
w = 9
while x > 0:
  d = x % w
  a *= d
  print(w, d)
  if d < 5:
    b += d
  x //= w
  w = 15 - w
print(a, b)