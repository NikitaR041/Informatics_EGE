min_A = 1000
for A in range(1,1000):
   f = True
   for x in range(1,1000):
       for y in range(1,1000):
           if not (((x - 20 < A) and (10 - y < A)) or ((x + 4) * y > 45)):
              f = False
              break
       if f == False:
           break
   if f == True and A < min_A:
      min_A = A
      break
print(min_A)

