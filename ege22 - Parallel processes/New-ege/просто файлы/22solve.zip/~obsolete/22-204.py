# x = int(input())

x = int( '71111111', 11 )
print(x)
a = 4
b = 10
while x > 0:
  d = x % 11
  a *= d
  if d < 5:
    b += d
  x //= 11
print(a, b)