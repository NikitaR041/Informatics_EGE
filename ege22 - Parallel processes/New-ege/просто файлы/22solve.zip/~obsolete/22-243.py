#s = int(input())
def f(s):
    k1 = k2 = 0
    while s > 0:
      d = s % 10
      if d > 5:
        s = s - 1
        k1 += 1
      else:
        s = s // 10
        k2 += 1
    return k1+k2

print( f(799999999999) )

