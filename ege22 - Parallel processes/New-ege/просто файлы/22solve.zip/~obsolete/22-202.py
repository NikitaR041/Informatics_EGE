# x = int(input())

x = int( '62111111111', 7)
print(x)
a = 1
b = 3
while x > 0:
  d = x % 7
  a *= d
  if d < 4:
    b += d
  x //= 7
print(a, b)