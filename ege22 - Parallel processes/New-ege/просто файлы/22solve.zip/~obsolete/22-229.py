for s0 in range(1,10000):
  s = s0 #int(input())
  P = 13
  Q = 4
  K1 = 0
  K2 = 0
  while s != 1280:
    if s > 1280: break
    s = s + P
    K1 = K1 + 1
  if s != 1280: continue
  while s != Q + K1:
    if s < Q + K1: break
    s = s - Q
    K2 = K2 + 1
  if s < Q + K1: continue
  K1 += s
  K2 += s
  #print( s0, K1, K2 )
  if K1 == 36 and K2 == 335:
    print( s0 )


