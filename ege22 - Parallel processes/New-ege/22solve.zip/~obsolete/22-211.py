# x = int(input())

def dupSystem( s, b1, b2 ):
  if len(s) == 1:
    return int(s)
  else:
    return dupSystem( s[:-1], b2, b1 )*b1 + int(s[-1])

s = '53311111111'
x = dupSystem( s, 7, 5 )

print(x)
a = 5
b = 13
w = 7
while x > 0:
  d = x % w
  a *= d
  print(w, d)
  if d < 5:
    b += d
  x //= w
  w = 12 - w
print(a, b)