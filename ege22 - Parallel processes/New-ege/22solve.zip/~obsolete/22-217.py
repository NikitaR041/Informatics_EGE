#x = int(input())
xx = 1
while xx < 100000:
    x = xx
    a = 14; b = 100
    while x > 0:
      a -= 1
      if x % 2 == 1:
        b -= x % 64
      x //= 8
    if a == 10 and b == 79:
       print( xx)
    xx += 1