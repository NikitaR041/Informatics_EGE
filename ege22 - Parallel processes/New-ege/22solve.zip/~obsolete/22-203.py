# x = int(input())

x = int( '32111111111', 6 )
print(x)
a = 5
b = 20
while x > 0:
  d = x % 6
  a *= d
  if d < 3:
    b += d
  x //= 6
print(a, b)