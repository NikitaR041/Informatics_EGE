for s0 in range(1,10000):
  s = s0 #int(input())
  P = 29
  Q = 11
  K1 = 0
  K2 = 0
  while s != 2520:
    if s > 2520: break
    s = s + P
    K1 = K1 + 1
  if s != 2520: continue
  while s != Q + K1 + K2:
    if s < Q + K1 + K2: break
    s = s - Q
    K2 = K2 + 1
  if s < Q + K1 + K2: continue
  K1 += s
  K2 += s
  #print( s0, K1, K2 )
  if K1 == 314 and K2 == 470:
    print( s0 )


