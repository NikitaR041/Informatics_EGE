#x = int(input())
xx = 1
while xx < 100000:
    x = xx
    a = 3; b = 12
    while x > 0:
      a += 1
      if x % 2 == 1:
        b += x % 100
      x //= 10
    if a == 7 and b == 255:
       print( xx)
    xx += 1