# x = int(input())

x = int( '322111111111', 4 )
print(x)
a = 2
b = 3
while x > 0:
  d = x % 4
  a *= d
  if d < 3:
    b += d
  x //= 4
print(a, b)