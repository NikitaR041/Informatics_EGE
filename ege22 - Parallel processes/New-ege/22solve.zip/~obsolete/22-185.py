d ={}
for x in range(1,10000):
  a = 5*x + 345
  b = 5*x - 807
  if b < 0: continue
  while a != b:
    if a > b:
      a -= b
    else:
      b -= a
  if not a in d:
    d[a] = x
    print( x, a )