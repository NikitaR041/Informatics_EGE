N = 84000000
Dmax = 2

x = '88755555543'
s = sum( map(int, list(x)) )

x = int(x)
print( f"x = {x}, r = {N}" )
print( f"maxB = {s}" )

a = 1; b = 0
while x > 0:
  d = x % 10
  a *= d
  if d > Dmax:
    b += d
  x //= 10

print(a, b)