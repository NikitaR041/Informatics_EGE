# x = int(input())

x = int( '52111111', 9)
print(x)
a = 1
b = 0
while x > 0:
  d = x%9
  a *= d
  b += d
  x //= 9
print(a, b)