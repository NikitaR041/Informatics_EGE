#x = int(input())
xx = 1
while xx < 100000:
    x = xx
    a = 0; b = 0
    while x > 0:
      a += 1
      if x % 2 == 1:
        b += x % 100
      x //= 10
    if a == 3 and b == 126:
       print( xx)
    xx += 1