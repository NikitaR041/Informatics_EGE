#x = int(input())
xx = 1
while True:
  x = xx
  S = 1
  A = 5
  while x // 7 > 0:
    if x % 2 == 0:
      S = S + A
    else:
      S = S * (x % 7)
    x = x // 7
  if S > 100:
    print(xx)
    break
  xx += 1



