count = 0
for s0 in range(-10000, 10000):
    s = s0 #int( input() )
    P = 20
    Q = 13
    K1 = 0
    K2 = 0
    while s < 230:
      s = s + P
      K1 = K1 + 1
    while s >= Q:
      s = s - Q
      K2 = K2 + 1
    if (K1, K2) == (12, 18):
      count += 1

print( count )
