#x = int(input())
xx = 1
while xx < 100000:
    x = xx
    a = 5; b = 8
    while x > 0:
      a += 1
      if x % 2 == 1:
        b += x % 100
      x //= 10
    if a == 8 and b == 146:
       print( xx)
    xx += 1