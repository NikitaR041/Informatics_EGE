count = 0
for s0 in range(-10000,10000):
    # s = int(input())
    s = s0
    P = 12
    Q = 8
    K1 = K2 = D = 0
    s = s + 21
    while s >= 43:
      s -= 43
      D += 1
    while s < 0:
      s += 43
      D -= 1
    while D <= 100:
      D = D + P
      K1 = K1 + 1
    while D >= Q:
      D = D - Q
      K2 = K2 + 1
    K1 += D
    K2 += D
    if K1 == 13 and K2 == 17:
       count += 1

print( count )
