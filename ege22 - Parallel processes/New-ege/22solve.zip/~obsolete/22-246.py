for x0 in range(1000):
    x = x0 #int(input())
    a = 0
    b = 0
    while x > 1:
      a = a + 1
      if x % 2 == 0:
        x = x // 2
      else:
        x = 3*x + 1
      if x > b:
        b = x
    if (a, b) == (9, 256):
      print( x0 )
      break
