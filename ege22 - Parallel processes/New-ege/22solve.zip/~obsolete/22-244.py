for xx in range(1000000):
    x = xx
    N = 0
    S = 0
    while x > 0:
      N = N + 1
      S = S + x % 2
      if N % 2 > 0:
        S = S + x % 4
      x = x // 2
    if N == 6 and S == 6:
      print( xx )
