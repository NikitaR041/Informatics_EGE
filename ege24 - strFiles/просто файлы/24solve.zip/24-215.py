s = open('24-215.txt').readline()

B = ['A', 'B', 'C']
D = ['1', '2', '3']
maxLen = L = 0
for m in range(3):
  for i in range(m,len(s)-2, 3):
    if s[i] in D and s[i+1] in B and s[i+2] in D:
      L += 1
      maxLen = max( L, maxLen )
    else:
      L = 0

print( maxLen )

