s = open("24-241.txt").readline()

chunks = s.split('O')[1:-1]

L = [ len(chunk) for chunk in chunks
                     if chunk.count('F') <= 2 ]

print( max(L) + 2 )

