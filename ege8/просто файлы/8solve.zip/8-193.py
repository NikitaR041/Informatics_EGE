count = 1
start = int('300000',5)
end = int('400000',5) - 1
print( (end - start + 1) // 2 )
