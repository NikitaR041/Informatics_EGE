# Автор: Е. Джобс

from math import factorial as f

# n =   f(26)//f(16)     все комбинации
#     - f(21)//f(21-10)  без гласных вообще
#     - 10*5*f(21)//f(21-9)  с одной гласной

n = f(26)//f(16) - f(21)//f(21-10) - 50*f(21)//f(12)
print( n )

print( sum( d for d in map(int, str(n)) ) )

